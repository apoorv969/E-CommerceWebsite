import React from 'react'
import Signup from '../features/auth/components/Signup'
const SignupPage = () => {
  return (
    <div>
      <Signup></Signup>
    </div>
  )
}

export default SignupPage
