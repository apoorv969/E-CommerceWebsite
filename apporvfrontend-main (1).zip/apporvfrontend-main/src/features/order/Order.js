import React from 'react';
import { useDispatch } from 'react-redux';
import { } from './counterSlice';

export default function Order() {
 
  const dispatch = useDispatch();

  return (
    <div>
      <div>
      
      </div>
    </div>
  );
}
